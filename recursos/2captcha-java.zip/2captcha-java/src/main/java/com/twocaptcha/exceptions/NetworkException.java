package com.twocaptcha.exceptions;

public class NetworkException extends Exception {

    public NetworkException(String errorMessage) {
        super(errorMessage);
    }

}
